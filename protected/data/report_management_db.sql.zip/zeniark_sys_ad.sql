-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 02, 2014 at 05:38 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `zeniark_sys_ad`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(120) DEFAULT NULL,
  `password` varchar(120) DEFAULT NULL,
  `salt` varchar(120) DEFAULT NULL,
  `account_type` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=98 ;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`id`, `username`, `password`, `salt`, `account_type`) VALUES
(1, 'admin', '34993d875f951b6db464474aee27bd4b7040bd58', NULL, 1),
(2, 'georaldc', 'ee0dec6af25ebae3b55f482a0a551dde9fe020c8', NULL, 2),
(3, 'annec', '517f33ee7b1056a709f29b9cc0fafa41462f9262', NULL, 2),
(5, 'alexw', 'ab128b04cfda3c086fcc88341d1b49335a599a75', NULL, 2),
(6, 'jeanc', '1b2a4270e5d6e6eb6049b671b27c931e34278eec', NULL, 2),
(9, 'johnb', 'ff9c3c7311d48261c6bcac09f7cce33c23c023ee', NULL, 2),
(10, 'lennardc', '70b9c1ceba88a9a73851c55bfa74b7bf64d89952', NULL, 2),
(11, 'jeffc', '93507b545838224b742e4fa847d9019a448d1ff3', NULL, 2),
(12, 'terencer', 'e5e8664246ab1f70f1538aca8009eecee0a6a738', NULL, 2),
(13, 'gracem', 'a14217290dadc4e565d84646cbf6e785c752b2da', NULL, 2),
(14, 'jamiec', '259d202d5d1cae07ce4162b1e221217e63d16c64', NULL, 2),
(15, 'irenem', 'af1c98db022eddf3a47c494258ae6c52f74a51e1', NULL, 2),
(16, 'judye', 'ff432c2ba2daa28de96aab4654f8f88df153b25c', NULL, 2),
(17, 'pauls', '05968102c18f350d1477461a0368c540921993be', NULL, 2),
(18, 'kent', '03131e857bf6cbbd5a90fb24fdea670be7d6a438', NULL, 2),
(19, 'jayl', 'e82e5de676b1d234bad6e16c5965415ce0ead49f', NULL, 2),
(20, 'lee', '4e5e66dbd2a210fbbeef575a02210e24f9858cf2', NULL, 2),
(21, 'arvind', 'f72bc9a59e29af726ede6aa9fe9e058ed6e7e90a', NULL, 2),
(22, 'jeffreyt', 'c65120db2493b9f74183882837ffb60908a89e4f', NULL, 2),
(23, 'eldond', 'be32600836b1ce5f3157d10b269fcf47d0747445', NULL, 2),
(24, 'leilac', 'b080961d90f096992530c8a89a9335325ed3d3ba', NULL, 2),
(25, 'kurta', 'b108302d5fccff3cc18fba096d08f2b7ae008e86', NULL, 2),
(34, 'redena', 'aa2599d2ff6f885af84998b792691cf723b8b0cd', NULL, 2),
(35, 'fayeu', '17dbeb1a39be663e61181e71cc1034a2758a75da', NULL, 2),
(36, 'nikkig', '20b346a94985bd936e78161869f366437110fb07', NULL, 2),
(37, 'pamelap', '895e0f6d94d8e81334bd4563deed93a6f151c2c6', NULL, 2),
(38, 'rachelles', '9292aab45f3fa07d6280275d2e6f6f0b8a30c194', NULL, 2),
(39, 'melanier', '8dffa5186f89fe202b8014a13a7e75bba67469ea', NULL, 2),
(40, 'jennyp', 'a7d622a9b1f9d283286e34c95b298e164008c6b0', NULL, 2),
(41, 'karenn', '5b55eb71bff63a2095e415d64e94b6cdf1a07c07', NULL, 2),
(42, 'cathy', '6b4212bebca28cf58cb5a9de92149ef63a462b26', NULL, 2),
(45, 'francisd', '16c3a162d45fef6b61cbcfbbf7844f731282ca38', NULL, 2),
(46, 'rsacramento', 'ce7907b7579897e9e4afd78452fe75f3bed2397d', NULL, 2),
(48, 'loisp', '65627f66f6d29f8354213db3a5b5607e13ca99be', NULL, 2),
(49, 'nicol', '196a3df5e04a56015420a9c6f53250f38a6bbbf1', NULL, 2),
(50, 'jettm', '44e3b12342e437c2cbf9d8859602cd708c37e00f', NULL, 2),
(51, 'cindys', '7f6375a27dd3adf60938592062a3f26c73452657', NULL, 2),
(52, 'dinop', '15609930ad82e8fd9ae83797b227cc109f026504', NULL, 2),
(53, 'adrianec', '889a322cca9566870f55bc9f11cfb4b3eef4beee', NULL, 2),
(54, 'katrinal', 'e354f2eb7b4e0c370a38737781e63af9718181c2', NULL, 2),
(55, 'friedels', '39def406abb2cdc693f5c2b9ba80e8000c120c86', NULL, 2),
(56, 'maryb', 'b13fd9aa448b664a724ce2e6874e45cb6e2e0fc6', NULL, 2),
(57, 'amyp', '8f0fa4e0cc5879f3c8add36e64a87851a3b5d813', NULL, 2),
(58, 'ricka', '9b965e88946942aea5bda2a6ae63e98a0f828015', NULL, 2),
(59, 'joanned', '7eb009604f73880dd14bfdbc1cfdd58bc35ea363', NULL, 2),
(60, 'bhellas', '8e1a98b1d52ecd8ca80d85d00b80e65c448f7fb3', NULL, 2),
(61, 'margiem', '41922c5efee3a5afaaf5ac9b80a301997647c8a8', NULL, 2),
(62, 'erwind', 'dad99b52a79320b9419a2d7a9c41e45d921af1d2', NULL, 2),
(63, 'markj', '8fcaaa7b005e213d197023a9106a9f72d8934692', NULL, 2),
(64, 'leslied', '1768ee0b23b3946dc10faf99ad77acc5efb95d3e', NULL, 2),
(65, 'jurie', '62a5fa81890264ee0504d3f21ff4791571bc2ea8', NULL, 2),
(66, 'jemp', '9136d8b0f3e2f57fc7df84d7fc9143ee4ef02b7b', NULL, 2),
(67, 'krishap', '3c5bbc0ebde28e5361a136cdc4350acab2cc4713', NULL, 2),
(68, 'gales', '413892bd59dbee0279811336cede99988a45d50e', NULL, 2),
(69, 'ruthc', '1886fbaed1ac25347fad58e8a28287e104cbb6ec', NULL, 2),
(70, 'micahd', '0cc0ecc2a51fe504cb48dd10757eb7367bd16bbb', NULL, 2),
(71, 'alyssam', 'dc86631a5042ba9bd1e695bc1d99e0df35e46e34', NULL, 2),
(72, 'riaj', '734ce4ee31297e6fecb3114bdc231188a1cea08e', NULL, 2),
(73, 'aubreyg', '1a78262d9769a608e7bed60ba5d1836d37c54444', NULL, 2),
(74, 'louiel', 'cd175a1824dd989f71dd0d56edbb219897ba6fc3', NULL, 2),
(75, 'armeec', '505a0f7fc424262660e1d96f1c5325a937c5c9a0', NULL, 2),
(76, 'roseanns', '81614ed46bab50e93dbc2e2e517c34d8bf1250ba', NULL, 2),
(81, 'lawrences', '5ed6153f1e21b250328f5d58acae48eb787bfad8', NULL, 2),
(82, 'patrickp', 'ebb503e9ddd416ddea59070718f27045d935bad3', NULL, 2),
(83, 'benjiec', 'ed00f8ddfa5d2fc50d2a5130d519ffa56ecca1b1', NULL, 2),
(85, 'adrianebrentc', '95656333888700a89b55f1d03100e822b018f03d', NULL, 2),
(86, 'chrystylljoyp', '1aef9fedffcca9bbc7e95251e7d758a84e075127', NULL, 2),
(87, 'catherinejoys', 'b4d86f8e93bb7df20e97a49ce07ced3987f17dd6', NULL, 2),
(88, 'cherriemaem', 'ff00c57d10a67bfed7dff798bfa72d9486df363a', NULL, 2),
(89, 'rizzat', '61f9119d6e94cdbbaaa46ae71958e00944b61033', NULL, 2),
(90, 'neilvinn', 'e6c96c8eca71c08ebc5fa6c644a9a2a236f90dcd', NULL, 2),
(91, 'winefridag', '63231af85e7dbd34dc3b8a18484eac5a512be113', NULL, 2),
(92, 'josel', '1061de30274685ba7b1ed60554194e6b76b6c4a3', NULL, 2),
(93, 'virgilioc', '5e26a63b7affdbba0aed10b34d978ca3bc2b5b3d', NULL, 2),
(94, 'celm', '78782a609460a794caa6c2e961d48194bfcf1cbe', NULL, 2),
(95, 'veronicav', '7920643216db00fd949975a6d3d54dda2e6c842d', NULL, 2),
(96, 'shirleyb', '10a9e86c326c3a62b2a2012015ed0c6c98184d10', NULL, 2),
(97, 'jessg', '7f227335c201f44f1e609bffaab536794446f609', NULL, 2);

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE IF NOT EXISTS `client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_name` int(11) NOT NULL,
  `email_address` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `status` tinyint(4) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `client`
--


-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE IF NOT EXISTS `employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  `first_name` varchar(120) DEFAULT NULL,
  `middle_name` varchar(120) NOT NULL,
  `last_name` varchar(120) DEFAULT NULL,
  `email_address` varchar(120) DEFAULT NULL,
  `timesheet_code` varchar(20) DEFAULT NULL,
  `default_shift_in` time DEFAULT NULL,
  `default_shift_out` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `account_id_UNIQUE` (`account_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=97 ;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `account_id`, `first_name`, `middle_name`, `last_name`, `email_address`, `timesheet_code`, `default_shift_in`, `default_shift_out`) VALUES
(2, 2, 'Georald', 'Tumamak', 'Camposano', '', 'georaldc', '21:00:00', '06:00:00'),
(3, 3, 'Jurich Anne', 'Fernandez', 'Gomez', NULL, 'annec', '21:00:00', '06:00:00'),
(5, 5, 'Aico', '', 'Wei', '', '9876543210', '21:00:00', '06:00:00'),
(6, 6, 'Mirasol', 'D.', 'Cacao', '', 'jeanc014', '22:00:00', '07:00:00'),
(9, 9, 'Jonald', '', 'Balingit', '', '9876543210', '21:00:00', '06:00:00'),
(10, 10, 'Lennard', '', 'Celso', '', '9876543210', '21:00:00', '06:00:00'),
(11, 11, 'Jeffrey', '', 'Cunanan', '', '9876543210', '06:00:00', '15:00:00'),
(12, 12, 'Terence Nigel', '', 'Remollo', '', '9876543210', '21:00:00', '06:00:00'),
(13, 13, 'Mary Grace', 'P.', 'Maglalang', '', 'gracem017', '22:00:00', '07:00:00'),
(14, 14, 'Princess', '', 'Cascano', '', '9876543210', '21:00:00', '06:00:00'),
(15, 15, 'Irene', 'D.', 'Medina', '', 'irenem012', '06:00:00', '15:00:00'),
(16, 16, 'Judy Ann', 'B', 'Esguerra', '', '9876543210', '22:00:00', '07:00:00'),
(17, 17, 'John Paul', '', 'Santos', '', 'pauls023', '21:00:00', '06:00:00'),
(18, 18, 'Genesis', '', 'Tan', '', '9876543210', '21:00:00', '06:00:00'),
(19, 19, 'Arrenz Jay', '', 'Lumanlan', '', '9876543210', '21:00:00', '06:00:00'),
(20, 20, 'Arvelie', '', 'Lumba', '', '9876543210', '21:00:00', '06:00:00'),
(21, 21, 'Arvin', '', 'Dalusung', '', '9876543210', '21:00:00', '06:00:00'),
(22, 22, 'Jeffrey', '', 'Tanglao', '', '9876543210', '21:00:00', '06:00:00'),
(23, 23, 'Eldon', '', 'Dometita', '', '9876543210', '21:00:00', '06:00:00'),
(24, 24, 'Lady Anne', 'M.', 'Cunanan', '', 'leilac032', '21:00:00', '06:00:00'),
(25, 25, 'Alessi', 'D.', 'Antonio', '', '9876543210', '21:00:00', '06:00:00'),
(34, 34, 'Reden', 'A', 'Abuyan', 'redena@zeniark.com', 'redena035', '06:00:00', '15:00:00'),
(35, 35, 'Normilyn', '', 'Uban', '', 'fayeu036', '20:00:00', '05:00:00'),
(37, 37, 'Pamela', '', 'Pare', 'pamelap@zeniark.com', '9876543210', '21:00:00', '06:00:00'),
(38, 38, 'Rachelle', '', 'Simon', '', '9876543210', '21:00:00', '06:00:00'),
(40, 40, 'Jenny', '', 'Pangan', 'jennyp@zeniark..com', '9876543210', '21:00:00', '06:00:00'),
(41, 41, 'Charmine', '', 'Nicdao', 'karenn@zeniark.com', '9876543210', '21:00:00', '06:00:00'),
(42, 42, 'Anne Cathleen', '', 'Dela Resma.', '', '9876543210', '21:00:00', '06:00:00'),
(45, 45, 'Francis Ivan', 'E.', 'Datu', '', 'francisd042', '20:00:00', '05:00:00'),
(46, 46, 'Rizalito', '', 'Sacramento', 'tsacramento@zeniark.com', '9876543210', '21:00:00', '06:00:00'),
(48, 48, 'Adeluiza', '', 'Pingol', 'lois@zeniark.com', '9876543210', '21:00:00', '06:00:00'),
(49, 49, 'Nico Romeo', 'S', 'Lopez', '', '9876543210', '21:00:00', '06:00:00'),
(50, 50, 'Jett Vincent', '', 'Medina', '', '9876543210', '13:00:00', '22:00:00'),
(51, 51, 'Grosette', '', 'Sanchez', 'cindys@zeniark.com', 'cindys047', '21:00:00', '06:00:00'),
(52, 52, 'Dino Dann', 'P', 'Pardorla', 'dinop@zeniark.com', 'dinop048', '21:00:00', '06:00:00'),
(53, 53, 'Adriane Brent', 'S.', 'Castro', 'adrianec@zeniark.com', 'adrianebc', '05:00:00', '14:00:00'),
(54, 54, 'Lawrence', 'G. ', 'Sumpay', 'lawrences.zeniark@gmail.com', 'lawrences072', '22:00:00', '07:00:00'),
(55, 55, 'Friedel', '', 'Santos Jr', '', 'friedels051', '20:00:00', '05:00:00'),
(56, 56, 'Myla', 'E.', 'Blas', '', '9876543210', '12:10:00', '21:00:00'),
(57, 57, 'Maria Fatima', '', 'Pineda', 'amyp@zeniark.com', '9876543210', '22:00:00', '07:00:00'),
(58, 58, 'Rick Angelo', 'G.', 'Aquiatan', '', 'ricka054', '05:00:00', '14:00:00'),
(59, 59, 'Josefina', '', 'Dayrit', '', 'joanned055', '21:00:00', '06:00:00'),
(60, 60, 'Rheda', '', 'Soler', '', '9876543210', '22:00:00', '07:00:00'),
(61, 61, 'Marjorie', 'A.', 'Miranda', '', 'margiem056', '20:00:00', '05:00:00'),
(62, 62, 'Erwin Joseph', 'M.', 'Datu', '', 'erwind060', '20:00:00', '05:00:00'),
(63, 63, 'Mark Wilfred', 'B.', 'Juan', '', 'markj061', '20:00:00', '05:00:00'),
(64, 64, 'Leslie Renee', 'A.', 'Dizon', '', 'leslied058', '05:30:00', '14:30:00'),
(65, 65, 'Juri', 'C.', 'Espinosa', '', 'jurie059', '05:00:00', '14:00:00'),
(66, 66, 'April Jem', 'D.', 'Pamindanan', '', 'jemp062', '21:00:00', '06:00:00'),
(67, 67, 'Krisha Haidei', 'M', 'Pelayo', '', 'krishap063', '22:00:00', '07:00:00'),
(68, 68, 'Kristal Gale', 'L', 'Simbillo', '', 'gales064', '21:00:00', '06:00:00'),
(69, 69, 'Ruth ', '', 'Cruz', '', 'ruthc066', '21:00:00', '06:00:00'),
(70, 70, 'Micah ', 'Eunice', 'Dizon', '', 'micahd064', '06:00:00', '15:00:00'),
(71, 71, 'Alyssa ', 'Karla ', 'Mungcal', '', 'alyssam065', '21:00:00', '06:00:00'),
(72, 72, 'Maria Arceli ', 'B.', 'Julao ', '', 'riaj068', '21:00:00', '06:00:00'),
(73, 73, 'Aliana ', 'B.', 'Gutierrez ', '', 'aubreyg', '21:00:00', '06:00:00'),
(74, 74, 'Louie Daniel', 'M.', 'Lagman', '', 'louiel067', '06:00:00', '15:00:00'),
(75, 75, 'Armee', 'D.', 'Cabayao', '', '12345678', '21:00:00', '06:00:00'),
(76, 76, 'Rose Ann', '', 'Santos', '', 'roseanns069', '21:00:00', '06:00:00'),
(80, 81, 'Lawrence', '', 'Sumpay', 'lawrences.zeniark@gmail.com', 'lawrences072', '20:00:00', '05:00:00'),
(81, 82, 'Patrick Louie', '', 'Pilapil', 'patrickp.zeniark@gmail.com', 'patrickp067', '06:00:00', '15:00:00'),
(82, 83, 'Benjie', '', 'Cimagala', '', 'benjiec', '13:00:00', '15:00:00'),
(84, 85, 'Adriane Brent', 'S.', 'Castro', '', 'adrianec', '06:00:00', '15:00:00'),
(85, 86, 'Chrystyll Joy', '', 'Pilla', 'joyp.zeniark@gmail.com', 'joyp071', '22:00:00', '07:00:00'),
(86, 87, 'Catherine Joy', '', 'Sanchez', 'catherines.zeniark@gmail.com', 'catherines073', '21:00:00', '06:00:00'),
(87, 88, 'Cherrie Mae', 'P.', 'Mallari', '', 'cherriem075', '21:00:00', '06:00:00'),
(88, 89, 'Rizza', '', 'Tayag', 'rizzat.zeniark@gmail.com', 'rizzat', '07:00:00', '16:00:00'),
(89, 90, 'Neilvin', 'A.', 'Narvaez', 'neilvinn.zeniark@gmail.com', 'neilvin074', '20:00:00', '05:00:00'),
(90, 91, 'Winefrida', '', 'Gopez', '', 'winefridag078', '07:00:00', '10:00:00'),
(91, 92, 'Jose', '', 'Lagman', '', 'josel', '07:00:00', '09:00:00'),
(92, 93, 'Virgilio', '', 'Carpio', '', 'virgilioc079', '05:00:00', '09:00:00'),
(93, 94, 'Celia', 'C.', 'Moya', '', 'celm077', '04:00:00', '13:00:00'),
(94, 95, 'Veronica', 'Pineda', 'Villa', '', 'veronicav076', '04:00:00', '13:00:00'),
(95, 96, 'Shirley', 'L.', 'Ballenas', '', 'shirleyb', '04:00:00', '08:00:00'),
(96, 97, 'Maria Jesus Emmanuelle', 'T.', 'Guilas', '', 'jessg', '04:00:00', '13:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `employee_settings`
--

CREATE TABLE IF NOT EXISTS `employee_settings` (
  `account_id` int(11) NOT NULL,
  `group` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `serialized` text NOT NULL,
  PRIMARY KEY (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee_settings`
--


-- --------------------------------------------------------

--
-- Table structure for table `report_projects`
--

CREATE TABLE IF NOT EXISTS `report_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `status` tinyint(4) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `added_by_account_id` int(11) NOT NULL,
  `estimated_hours` float(14,4) NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `client_id` (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `report_projects`
--


-- --------------------------------------------------------

--
-- Table structure for table `report_projects_task`
--

CREATE TABLE IF NOT EXISTS `report_projects_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  `assigned_by_account_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `notes` text NOT NULL,
  `status` tinyint(4) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `estimated_hours` float(14,4) NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `report_projects_task`
--


-- --------------------------------------------------------

--
-- Table structure for table `report_projects_task_item`
--

CREATE TABLE IF NOT EXISTS `report_projects_task_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `project_task_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `notes` text NOT NULL,
  `status` tinyint(4) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `completion_time` float(14,2) NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `report_projects_task_item`
--


--
-- Constraints for dumped tables
--

--
-- Constraints for table `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `account_id` FOREIGN KEY (`account_id`) REFERENCES `account` (`id`) ON UPDATE NO ACTION;
